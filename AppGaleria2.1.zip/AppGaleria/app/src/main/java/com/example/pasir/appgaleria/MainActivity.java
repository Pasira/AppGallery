package com.example.pasir.appgaleria;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ResourceBundle;
import java.util.ServiceConfigurationError;

public class MainActivity extends AppCompatActivity {

    private EditText Username;
    private EditText Password;
    private Button Login;
    private Button Registro;
    private TextView Info;
    private int counter = 5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Username = (EditText) findViewById(R.id.etUsername);
        Password = (EditText) findViewById(R.id.etPassword);
        Login = (Button) findViewById(R.id.btnLogin);
        Registro = (Button) findViewById(R.id.btnRegistro);
        Info = (TextView) findViewById(R.id.tvInfo);

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validar(Username.getText().toString(), Password.getText().toString());
            }
        });

        Registro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ResgistroActivity.class);
                startActivity(intent);
            }
        });
    }

    private void validar (String userUsername, String userPassword) {

        if ((userUsername.equals("Anonymous")) && (userPassword.equals("hacker"))){
            Intent intent = new Intent(MainActivity.this, SecondActivity.class);
            //Toast de Bienvenida:
            Toast toast =
                    Toast.makeText(getApplicationContext(),
                            "Bienvenido MY FRIEND!", Toast.LENGTH_SHORT);

            toast.show();

            startActivity(intent);
        }else{
            counter--;

            Info.setText("Intentos restantes " + String.valueOf(counter));

            if (counter == 0){
                //Toast de denegacion
                Toast toast =
                        Toast.makeText(getApplicationContext(),
                                "Se acabaron las oportunidades...", Toast.LENGTH_SHORT);

                toast.show();

                Login.setEnabled(false);
            }
        }

    }
}
