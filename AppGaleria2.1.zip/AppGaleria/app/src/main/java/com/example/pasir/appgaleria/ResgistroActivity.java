package com.example.pasir.appgaleria;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.net.UnknownServiceException;

public class ResgistroActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText Email;
    private EditText Password;
    private Button Registrarse;

    FirebaseAuth.AuthStateListener authentication;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resgistro);

        Email = (EditText) findViewById(R.id.etUsername);
        Password = (EditText) findViewById(R.id.etPassword);
        Registrarse = (Button) findViewById(R.id.btnRegistrarse);

        Registrarse.setOnClickListener(this);

    }

    private void registrar(String email, String pass) {
        FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    //Toast al Registrarse:
                    Toast toast =
                            Toast.makeText(getApplicationContext(),
                                    "Te has registrado correctamente", Toast.LENGTH_SHORT);

                    toast.show();
                } else {
                    //Toast Fail Inicio:
                    Toast toast =
                            Toast.makeText(getApplicationContext(),
                                    "No te has registrado correctamente", Toast.LENGTH_SHORT);

                    toast.show();
                }
            }
        });
    }

    //Verificacion:
    @Override
    protected void onStart() {
        super.onStart();
        FirebaseAuth.getInstance().addAuthStateListener(authentication);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if(authentication!=null){
            FirebaseAuth.getInstance().removeAuthStateListener(authentication);
        }
    }

    @Override
    public void onClick(View v) {
        String email = Email.getText().toString();
        String pass = Password.getText().toString();

        registrar(email, pass);
    }
}
