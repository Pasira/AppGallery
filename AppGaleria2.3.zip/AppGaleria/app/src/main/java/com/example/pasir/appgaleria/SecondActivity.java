package com.example.pasir.appgaleria;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

//ACTIVITY QUE SE INICIARÁ CUANDO HAGAN EL LOG IN O SE REGISTREN:

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
    }
}
